<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Cse@gcet</title>

  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Presento - v1.1.0
  * Template URL: https://bootstrapmade.com/presento-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-xl-10 d-flex align-items-center">
          {{-- <h1 class="logo mr-auto"><a href="index.html">Presento<span>.</span></a></h1> --}}
          <h1 class="logo mr-auto"><img src="https://geethanjaliapp.com/webimg/logo.png" alt=""></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li class="active"><a href="#header">Home</a></li>
              <li><a href="#about">About Department</a></li>
              <li><a href="#services">Syllabus</a></li>
              <li><a href="#portfolio">Staff</a></li>
              <li><a href="#team">Placement</a></li>
              {{-- <li><a href="blog.html">Blog</a></li> --}}
              {{-- <li class="drop-down"><a href="">Drop Down</a>
                <ul>
                  <li><a href="#">Drop Down 1</a></li>
                  <li class="drop-down"><a href="#">Deep Drop Down</a>
                    <ul>
                      <li><a href="#">Deep Drop Down 1</a></li>
                      <li><a href="#">Deep Drop Down 2</a></li>
                      <li><a href="#">Deep Drop Down 3</a></li>
                      <li><a href="#">Deep Drop Down 4</a></li>
                      <li><a href="#">Deep Drop Down 5</a></li>
                    </ul>
                  </li>
                  <li><a href="#">Drop Down 2</a></li>
                  <li><a href="#">Drop Down 3</a></li>
                  <li><a href="#">Drop Down 4</a></li>
                </ul>
              </li> --}}
              <li><a href="#contact">Contact us</a></li>
            </ul>
          </nav><!-- .nav-menu -->

          <a href="#about" class="get-started-btn scrollto">Know more</a>
        </div>
      </div>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container-fluid" data-aos="zoom-out" data-aos-delay="100">
      <div class="row justify-content-center">
        <div class="col-xl-10">
          <div class="row">
            <div class="col-xl-5">
              <h1></h1>
              <h2></h2>
              {{-- <a href="#about" class="btn-get-started scrollto">Know more</a> --}}
            </div>
          </div>
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container-fluid" data-aos="zoom-in">
        <div class="row justify-content-center">
            <h2 style="text-align:center;">Companies visited our Campus for Placements</h2>
<br>
          <div class="col-xl-10">
            <div class="owl-carousel clients-carousel">
               <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUwAAACYCAMAAAC4aCDgAAAAkFBMVEX////QJx3QJBnNAAD++PjTOC/OEQDVQjr12Nf++/rPHA/PGgzOCwDppaPggX3xycfdb2rednLPIBXnnJj109Hoop/88fDZVk/55eT66Ofuu7nZW1XqrarbZ2L01NP33t3wwsDhhYHVRT7kko7TODDaY17SLyXXT0jffHjttrTjjYrdcW3VRDzklpPgg3/YWFLuH4imAAARSklEQVR4nMVd6XriOBDEEohgiwEMOJyBEK5kksz7v93aJLsbq0uyLjP1a+YLIKssqe9Wp9MONr1+TBwuf07X6Wa/K7pOj3F2H+r98md7fRmuHopBS9y4omDRkadCSC7Pj9fhbGn5GAPuOVQmBJf97ceT27trB9csaQksz4TMjm+rwuIxBjJoqFTIfD18aJ0tMx54LO5088wkX893Tc8RRuZtoFzww9x2J7SCxzwGYw3IhTjMzesznMwKTKTb0Z2Yo3iNMgcLlMvmcW+QE3HIrDY8T4Y250p8dHsszhxskPOjfnnGIjOplieb/g1p9CKiTcFumuJZc6hFJPNG5+a+RJZYti196DQzOVmgR4lKZjkOvzzdmcxxGnUGdsjEJ9jskcksDxX5eVcuR3dfmF/I+JSIouhkJok431Ow9++hFkHI46x9MhMmn+/G5fBeahGaJx/X93obZJaLsw8P6Pgo8juqRRRZsmqfzFK9vc9Wf76vWkTA5PiHNtgSmeUo91CSWjfKm5Gd/1df2iIzSfhL+2TexShvABPD9slM2hdDK7www52ZbhPlEwOZsYaSEyMVwege0aPkaTgE51xKIVK7uYrHro5MZjMUl6JZkPK3VsmcIumTPw7C0e0Wu9FqMz31MplZHCXZ8Ut7IWSWR0DjWMVitpqfEiEbXp2ctsglNsp5XE/1cv95KafZxGaeVsPSlfn/edqIxWqSSOOL4y3K9N8oVpG1cLQsX8e8iU+WzgLJLFG8rrkwLE/Zmr45QqKTZe34VAerkzBNszKHRnibu6F4SfSqM8vaCmhc0JaQ85ZGK7fhRypNdDI5i0BmRafUhgfTQwsTK7GBC7PfzmBf6G7OptXJxIicBR5klnROtGenaEWkdzM0Ld62EVvSaWCTUuBFZqcz6+uGaWWGb2i09NTCSHV0n7mLM9qTzM7gyvEeYHn8xI8dNNzEPXxVy5Px6IxDZqfzqjlRsmvMydywRsujnQOFYpVaL05/MjtPCT44peqSDsUe6ett7ACMYm3r0Qggs1Mc4TvLI0v0ATTK+WvcUUyYa460mGR2igPUkSIbQnNslEcdowEjYeX9CyKzU7yjtcmSWJOosIQSQGqN8qftWMG2NsfBSf379e1junkyZkwuejYHZ53MHRloPP78mO+XOrOt20OvLOwNKXA1ykdc9XvJmkjskr9nmRCCi8N4qj/ti4tFyKQ+7xkZKK1SMyU/b6dYEVkg1xzrxRMOMyh9pN4op1Z89uvn37u64EeVMZlNRrpHHzezqZJpGOiyh8+OvhIxJISNcsPS9ybza56896LJzNw2smlJZoWcH1ZgjBfkve85k6YBTCDMTUZ5EJnJLVXrhJN+1k0Zyw5kVskwa7DZH8HZHMuoHEDLwPjroWSWSPkYHmqXBinkRGY1DN1gCzDhdOtDHQU2ytemr0Qgs/xKhuyr4mzWkBzJLI+rMRnjg86YpVEcmzt4TJmN8ihklps9AWfazhwJcybzv+DcD4Bk3jja0Qka5eYQfRwyK2f6lQp2aNlqJm1DZpJdVDZXVEpEsVCgpsASc8JyLDJLbt7pFngz2ekeZCaCnFkHepbwCPscpq83GeXxyCz1FyrpoAfrX2I8yEzkL2UEsDRFuKqJjfJLw7cikolyqJaGWIYXmYlUD2caUQ/3gy9hmF5vlH8DkFnLbnYhs9wHJGanydKp4EcmUzcxTbdgeWgtxgQa5Y2u55grM0EuMCgVb/Ajk+iRS7rPZWDtAE4g5I2R8shkJnyvDLCA0b0KnmQmUhliTUSQCAxqwwRCk1H+jdhkMq6uCqBXf0/Zk0xVDmzIACnV7l0AZFpllDe7o2KTWepiypmGbdzEn0zVPl7QQzMoejGAtoZN+k10MpP0qAwBUyKSADJzRdmkgRoRkgjkHylvJlMSiNSYh6oGQgd9/GmVTDqQ1MQ/FIH+i8he3lixrQdd6GBIjCbVqDNSsV9trodcauUKDbjSQw2QWZCByqE2F5gMo1jfr+T3VRnlgq2HUf4vVw0rU4Ni9nnW5hsQByp2eFg5JGYXoPIpe45qMgE2EDbKz1aaa+PK1KL7ynSiRc3jxbXFdt6dwYmyyc61M3FA5p/5JxKfoVGO/PwUnivzC0Nd+oasnzA4j9nWVYZcGfUzkXglUvs5qFOCalGTUf6NIDI7S036hmp5YeegJZkzuq4VA/2PSnfu620voGhtNMq/4b/NvzDHJ6esu+OgGmztxAUmTn0b/1bfFfN1aV7RgWS9vMJWZok9PDiVpVkk4EPWZFJtIKsL10/1WPVN7N1B6WOttQaTqdG2Fa8A0jesyQTPWH9XL0RGecZ7fY1y/YO6Ht54D08bP2NNJn1diucIFD05zsEwE2OkvI4IZOJcgLp5XIDla03mnvx+Ws/3oWSeXedQoQvVIoeamBhkdv6ATaz4FEGqiTWZz2QXK6HlSNscqsMuYfhQaX4D8M82z9eeTBrcEh+1DxC2vQQQmoVbdC7KykSHljIfulWtyRzSHxf1MOEkimo0RrEKO6P8G3HIRI296q90CRixI3MGFoxiAZEzJPfwDqNxbI3yb8QhE4VG61bK4J3uVSsyZ8BLwpK64kU+knqU88NWOyQWakQkMqmvQf2dLRcKQCIWwfIXsrAUrxE1/T0yZKALmxjli4+pAVciiL3IBL29FOVoNJ0rmNbk/RI85vMJl0oqXNHzWDjXQ0AbjdaUr6W6JH6CKjV+ZFJ9lyVOCdEzsnKF0PUGUMwrGrIjUb1GwFY7hApz8pTNL1ihoA+TOcUOHGJAapIk1WENeecY2CgnNeXODTT9yARmrVsqgH90sqAnjEVYVnl65CMkRjns1WGEJ5lE13OUhA5xc0WJpCeMc9wcG+VqmLWw7PHyA55k0oPLTaT6Z3RQ2Sccoxaaqj7VKPfoK+5JJg0RKjZfA7xzjQoaJ3WtR52ihUmWNzxXG+BJZqiRb50FJxRjmbqOXbPgkEsLGOXU4d8MTzKpNZY6NauxJZNk71IJq2Z8NAFW9RGj3JAcqUe8lelUSm+bOawaikD1c4yaY6O8p65u6OxsgieZ1Axx+yHLnHYip0GkwTGnHYSSy5embgB3tcidg/9AXR2ZUytGKzIF8dQC157jLt+ggUnFhimf3ABPMqneEF814vTgAEqNWylq184o97xuxZNMKuvcGoo1k8k41bWAUsNyJ1sSJhAKlYMnz86u0Wxz4dTGr5FMcabaI2qU46ZEwKo+xtT3AaulLeBHJj27HFdIA5kZfwPKI6zqddLYUSyQGuWvvi2H/cgkGSquhd8mMpkQ8I4HFGPO311Gxa121Cf3v24llqfd0dugJTMX/PgCi2lhKqVl9t/3Y8OkZmKUvwBfqx2AyGwGiiA6qs7ggW+Z2I/zGXao7ZATx837Nkf6ekZWwXToi/neiYQbUC6EY175ck4f5XVkuO9OU5LnsjALqDzKO11KoAOKm3tlqDjgAPsaqT5II2BVn1OkvAWgzGCPxBAXdFGuu6MofwqPlLcApKFE73FXQ9GHXNLjzgScQHjHRm8IKOGJHdvs5LfDLb3c+g5D5TH/09pDWwF6Ctzc7I5YaVr32aeldnRVfSHlWBGAr8Nqrif2RneiqUBKLYsivmBnlN8Xr3CVtNES/ht7oXHgsMxFp0EtkYBRfld8YMNFtrVbFlttd0633pmwqs/pnIiNxaOmDqilhbn7DfJ5viF+u/wSruprtfu6Gd2prvu1GkGMg9HW0G3b7cDsvCO1qPXu61oMhj1dWES2IMoX84OpcTnLnd4fNsqd1nY8FKOJ/toOh2IPK3SL/dvZeEtIwoTTIQ0TXZja6K379BCM+k+SH5ytPiYXabppRTV+tA9V+9SO/v1pNlrNr6ceN1W333hwLDCHER1ilD97e940Lrgu+cGqE4LRiU9awn/ih5L1BM4L9sGJrPmiKubkxNS02iH5pDuHBv46BPfoULuNQI0uIe2B/S/Qc74tETZVIy8ERjQcEdo9hqmSQBcljUWm67rERjlpM+qVDqMisK8RkQTa5LFIZDLnO1FhTbkaKcdphq6I3HGLVtb/izhkpsz1YjhY1UcSo7S9rZwQ1guOeAN1XY0ikSkurtY0NsrVuDSu/XNGCJnUPDbcvhyBTMbdvTwwgZAY5dB0d0dA/0zQ+XSrz9EJJzN1S5u/ARrl5LYW5xoVDbzJTFMaqTBdsR5KJuMnD4eZXaQcmu4e8O45fKHW8c54SV0YmZlXJyj4dknoCJruPvAjM0fX5Q6MndqDyMzE1cePC6v6iFcZJ7n7wKtPu+wjZQ80y/r5JX8ycz728z5/wliFapTDeLoXfG4QwIU3xsbiAWSmfO156TCu6mPKp2CSux+cycwk3nHDpjtGvMhkQo69Q/Kw+oRYozDJ3Q+ut67wCd5xMAJc+6o7mSzjOc6IswI0t4lRrjcz3OFyH1Am3+caOdDIpTOZuZDna0hgYYBb7ShHRtfYadUR9jdV8d6btnC3mUsXMqvBxGn6FJYGBKtPiFEOK88ZvZMMgM5AJRPdoSZFdpxsDAJVEwF2I5PdrlGr/MPn7XQUnE8Feq5UYyg7C8uo9+vEAicyhXr62mCrfuPX28dw/2Ce2rONDtBEJuuXo70N97NdnMwAqPAQoxyWApBKFgyqBniWrvxAcbJyXzWR6VY20QiY502Mcug4ti1cjNQ95ieeMjuPy53JhK12VKMclgJYJ83EJ/PDNg51XzKhwkMavUHHsXXSTGwyl5qEmb9Npp1RvghLmolM5lCfC/R3ycQJhKpRDl3C9kkzUckcHVxCzfckEys8ag0DdAk7JM1EJHO35Xq9G7zye5JpFylHAUmXrM9oZO7Gpryq7PRBtLw7kgmq0oFRDvueuOSTRyJz/8d4WKZ9UNx/PzJxDFytOi5wJYvDODHI3L0khg1e0XIs/iqZcMkRTRxaSE7ZIsFkPny8y4aWC2l1FcVfJBNGIVim5GnBsKXbRYEB7YgGxcP8JM15k7cHOlaGPCKz9nPtkYmr+uaDbg3YQnKKjlAy06syioKiWC4eRq8fvy8Zt9Eqs8PNGENkFj9+dtAambri67zmPcvhxUNuHWIpmQnLVa9bbdRvH5yw7DInTl/bCTTSZfmPkWjmh0rmYHNK8vzw4epp949CuNZRAjKj4r/8FXhhqxEKmRvGeXY8c87dgrzeLSFc+9C0TSb7v69wKJm/OH9+6A4GxSbhZwc2casdK9heA3QfMrPe/2GNQDJ/8f6uuyzRubme7dnEt2RZwdIlfBcy67lAYWTuK/7G5Rbnh/L9vHHrOxKgH8gObr3s2iUzTWs5cWFksmqVTPjwabYW5X/71h2a9VcFN8GjjrItMstlWc/jCiJzxKvUqknV56Dgi+r/lq6cgNRA6X7hb0tkZkI1w4LIfLtZdZPKs9itLJfu2a5pku7+UAu4dftokcxc/iIKWhCZp5slMuH7bvel2uadtVpNhmFKD22ATx1lC2QyfgEnWhCZX9xNsvM5+VK2TlZ2XkBqoFu3j7bIzGUPOlqCyNx+rcy01Nm/pNofq24cnn0aK9it/HbJzPlB47OKcGb+XneK5LZiCqurqJ78VUy/5kYxyWSZfNSeNBGkeUlmZ3MrNNpbSXPfPo2VUe7V+yYemalMPw0HWZie2au0oorMTu98+6+FnhlQr+daQBiVTJZKvl0ZldxQC+jc7Wwvt3+9lLalhc82IDWQRIfuR2aVNzleNTmrgm3z8255EwqL2ZX3LIyTEKPcs11LEJmsypuU65eZhdsv1Gs04fL5oegMFpsjP1uI2qVkvhC+bexG3GO0/OYhliI/Tja2eZNT4TqKEv2v/JnsnEjOrzZDXs89X/R9UxhHzHWoY/9wOf2+vmzc8iaHietAZ8Vr092M+73e2tLTbgy9mOHfxc5jLK/BzIEly0mVP2I53D95o1yvSvNO3wAAAABJRU5ErkJggg==" alt="">
                <img src="https://www.softwaresuggest.com/assets2/img/success_story/keka.png" alt="">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXMAAACICAMAAAAiRvvOAAAApVBMVEX///9GRUc5wdc/PkA8Oz1CQUOEhIUzMTR/f4A3NjlHRkifn6C9vb7GxsaKiYobvNRlZGYuLTC3t7dubm/v7+9OTU8rKSxRUVLU1NT5+fne3t7k5OTOzs6tra15eHr09PS15O2j3unm9vmG1eNgX2GSkZKbmpuX2ufi9PhxcXKmpaYAttGw4uzx+vx60eFgyt3G6vFVx9skIibV7/USEBUcGh4JBQ3kP8aOAAAMbElEQVR4nO3d64KiNhQAYBxAjLchqHh3prtqu7Z76fby/o9WdFRyTk5Iogh0JuenEiAfIUAIieeVE4t+rz3aTrpZTKbxZrdevdivZDzodeJJdxJ3eoOx4VY78bTbyqJ73Goym9tvdZHsvmR7Ph0N17OC/Zp2J9vNrr+038BDYrCJIhb4YesSoR8wPunR+7cfibG//Dw+TDgL3tYRZsm3fc1W+xuebTW8bjU8bXW7pg92LG40Hlx+XuxYdN7zLHkU7aRjPT5M+WUzoZ9lKzEyeWwcGPNbVAQ8pgpOJ8vANYLO24/LThrA1CELB0Tqc8x7Eb3VMEg71LFOhY2G0fl4LmKOVuKnO5BsuUmDEG6ABQX7VUkMAmQF9o+P5DqiLWbTfzPfpRRgtFFtNYkKtordThGJS7CT+bzDQzl10M13+aVD7hdv3812T7S5Ou+n/HOpUMjmM18hGEzp+nkU0cvnblJRl81XitMzjC6JE3wWXNOPyjS0jJgVZz6LdI3SSOaHVJnYnxIbnU8UFIIbx7WaZL5XbjUMTpeEecGRvVSJNcSo4Ay/Bkfo2HxYVGgDonrRk2eRLmAibP6loLT4cZZgERRtJtJd4R8VO30pP2UfljloPtSsRM5cbEKeucL7F2Ae9OPC0pJtNFGffG+rfyytKmaaujzPIqiVgXl2+6VJjDO3NjvQb4U1D3gy+cTFU4xJT5e3oPdoXjK6ZpnP9m8oJmubldNLsAPY6FhT/vKAZ4jmqivtsn6/KhCWIjEscFmk4m2EpXnLB1u1SB2K6SzN9cFWD9V9Je/YNKenGL5Y0G3NIzFz5sX8chd+jtLNQZ7O8fW1DO5j/Pid+nVlkwsuHDXrci5m7kCd9MdHS+rnrZCwdPNWi0D5/Ucp4t6P52fq545EF7CIH4N4KheLnMrcDxg7NttIf4h1hHQNCSI+2WYRcnmrXHgIVpiHp40qno6u+3VsTpKOKicadp6fS0F/fX4izXEmWPcwO+VxvhwMpWYM4TabNA94d7gezBarZCM9/Al0S3Q74QeH66ViNsSP8kGi3t3zVrf7/mwx6w8jRU3pM9ZZrxaL1XqLL18R0ZiUWb3eC34iJ81nKBMcNLfNN2gPo/w/wpz5OZ0376C0wtUqgVULg09MS/S0JB5pwpx119ej+ULe9ftpJ4fto+PNiMeiI9arjlQXR3LSHFWs0rP2EP4f5aaSeeCjvd9D9GCtSCs/gU9gcRXu5yRz1oVbnUolPUzboIVuANcR4EYN72R+N/qJnDTfgNwzeftbkAehUGBzLrcCxiCtny8whUmlhKjuEWolZB7iFglvIVWWW9xQNgK7FRw8Kd64Xgkv43gjJ83hxSyUF1gxxQ6i51BGVIuw4vLz4gzuFBnx9gAVhXzdUJTFchvzBJJzee0DmCXiSfTs9Sr/YxpnctIcFKhgTywBKhfhhg+aT8iXcCBt+OXy8xjIceKxAbIIZxdsb6H2dwfLArFfLzDTSvM70C/klDnMPflMBmzDEf27Tzf/b8SzOLy2nIDzH9x+XwKx5GcX3F/qTc8aHGiqERkdOLX50/MfZLa08cdlBZQ5rP0iqrCCq6wARL0nwrEHaa/moL6iHgTRGSKUZ715H5wiE2rlLbDyAvMb0XNyyhzW1tRZjtpj8jyYmPdoc1Bz0C174NItXH1LMQcXsULzm9AFcsoc1pucWgPMQ36PYWJ+MDEn7huweX4qVG1+A7pITpn3bc3zO5sPYm6NDsgp88SZ68yfnn8h86aIX0BaZ34JO3MrdETuzC9haW6Bjsmd+SVszY3RJXJnfglrc0N0mdyZX8Le3AidIv9NXsyZk+a/3YL+qxk5Mo+IJT6kOYn+K5nFa5iSO3NV24M1ujG5M1f25LJENyd35urec1boFuTOvKDHogW6DXlN5n3u5xEZtOXWYm6ObkWOzMn+kg8wn7WHebTJLuBlmXeplRuae5/M0CnyT8qV1mRuEI0wN0P/bEfeXPO4EeYk+me4iC15Y80HoMdEfeZ6dGvyZprPhhF8H1ijuQ7dnryB5ou9H+FeeXWaF6PfQI7MA2qRKs3H6ykneqbXal6ETpA/6chNzAdVmc+TGH8g3ghzNfotpRybhx0iYEfPh5kPNilTfWZzhzn1FYWtufeVRqdK+VftyvAHXD4RaGiCa9IyzY9XzYJvJOo2977KuBm6/KMJuc1Hcw8zX/ZC6arZMHMK/YkwNyFvgPkqpq6aTTOn0GVzI/LazVdT1RdADTMn0CVzM/KazccjE/FmmMvo2NyQvF7zPjXWDRV3mBNfjtxoLqF7t5HXar43HduhIeYY3buNvE7znfqT5pCxstq4yjT35mpzi89g6jNPlKXc59MEftvWFPPXZ6W5RZfp2sxVgyyELNodhyYqq/28THPYsxzX58YdSWszj8nLZ3AdjrGB5rhrHL5vMUWvy5waGymrxXfXz2fLMveJJW4zl3ojSvfnup5e5zBob4GRNz3eZS6PpuHzWHwZ3Thz+UWz/Bxqho7bFTfauCa9yxwX85C34RfiTTMn3u0T7S1G6Il+B1Vxj/kAVWn+FA3p1zRzgvyJbD7/rF+XwTsLVdxjvofNWr48nmezzCndb5737Sb0mszRexDiA/FGmSvIafRvurXVZA4fQSNcsXjlmZNZsjRXkhf+pYx6zOEICuQgCw0yL6xBbkCvx3wJB5YgBgpqkLmm0rZHr8d8BnvVUCPaN8Zce52keoh+L1pjPeZwNA1yBJOmmH/X9xKl7iOL0OsxR6NpUCOYNMT8u8wpP/dYojfCnErZDHMjcvLD0Kc/lSt15kXmFDnZeGiF7swLzP80JbdDNzB/6R3EuP7+/zAnuxqbmVuQS+8zitANzMc/gzxY3ufyvZtT5AXv3yj0J3JJE3OQzbxp5J2bE4LFrzxfKXT9oHLO/BJzwk/3ap9EJ7pgOHPSnOoSqu9N8cOsenHmpPlN5CS6dswcZ34Ows5o4H8ZvTHmq/+duelcCxK6Mz+H/RhoxtNb/GU71p8zPweGs5hRBKE783PYjmn5F5k5RUD0j2hODo9iOXarFTlCd+bnsBuj2JIcomvNyRMRmIcfztyeHAy2c9uYlnAihLy/RFnj/DfbvGC8oYLI0bXjn5NvJsEDTGjXXxF0BVWaP/Ld3J3mt5ELn6trx/kn8wDKqmreFsX3tuALlXz+EfQOmppTvhnmt5Ln6IQ57PXgU5PCqyZQgnPl+DFRWuHUTvnaoTk1+RicHK0uc4MBE5TxSTknFLwpaXG5yPVVPmgeLt+Xu6kM4WG5zgQCjzTx3WiMpiCux/we8gxdZY46gsu9Ncew13LRfHO8gy4HK7jy/BxB85NFaFqkPf5utCbzu8jPDcKUOfqux9/C2TQXaFiLwnkVfd4We3tKExhehWDfOdhJdLyPpO//6zE3/+JTEV8V5qgneCvk+xxg1kFs+fRl9PyhftTdDZbHmn3Z3+LvP/NzZI4/s+DD00ZfFmtyxIVazO8mP6GbzB+a7UMUTUfHmMpT1orT8SnmyfWPs+xGPJIHwBGyL5fkiLMgS1X6OEXkzb+JeQnkR3RynlzVxMzk1MypUPNYzwct3BR9sZj4u1WLeSnkxxGOqF9x5WLKZm0u3hKSU3AXbLdy85LIM3TqR5tZ37l4ibQ1F3MvTaxaHJWbl0auiJ1xmYOfWlmaC/P0eehBS5+2avOHh7F5Cu6/Lc1hYm3lAmc1fnfmM8PaJYLfoEDzrQaRwSltpbtFGOGkrHEtGmrurY0Gr2FoKlw0T+6icCUhHvt9XTTQgB/OQYvkOzT3egboDLd/4bbcpV9Q2citxFv10sF0Difhfo/mXj/VXdTkmeSl9vP5SHU3EnL5C9B5S7VJfhR+/+beUnpSBxEEcu6IdxYJI2v1oEW1kL9MyIVZeGrx+gDm2a52VYN5hoyc5oN6TzTfc+np3U/JSbazGKZ4iyFj58bHD2HueasOZwFSCAPGtwm5OP1ubn4cTTv/x2dphyrkb7HcpExcVtjU6CfP42f+5u9v4Wf+DzX9SPKPuMi/1HYjcYmfe2qR6mJ22Ew4jy7Bg3jXp96RHkP5PnS57nTTU/p0OuxTLzvzeEk6k/Oyk3ai2tT7j5flcnGMZTFB8Tvo8XKpSX/bsh87TN77uyg3nHn14cyrD2defTjz6sOZVx/OvPpw5tWHM68+nHn14cyrD2defTjz6sOZVx/OvPpw5tWHM68+nHn14cyrD2defTjz6sOZVx/OvPpw5tWHM68+Prz5f3MjMUVjJdlqAAAAAElFTkSuQmCC" alt="">
              <img src="https://logodix.com/logo/968624.png" alt="">
              <img src="https://pngimg.com/uploads/amazon/amazon_PNG6.png" alt="">
              <img src="https://seekvectorlogo.net/wp-content/uploads/2019/01/cognizant-vector-logo.png" alt="">
              <img src="https://res-5.cloudinary.com/crunchbase-production/image/upload/c_lpad,f_auto,q_auto:eco/e7dp3p53oqtop3lkj58m" alt="">
              <img src="https://www.logolynx.com/images/logolynx/8b/8bb0c7b1974daa33e4369f6aed383e20.jpeg" alt="">
              <img src="https://mma.prnewswire.com/media/1015155/HashedIn_Logo.jpg?p=publish" alt="">

              <img src="https://www.karnatakacareers.in/wp-content/uploads/2019/05/valuelabs.jpg" alt="">
              {{-- <img src="assets/img/clients/client-7.png" alt="">
              <img src="assets/img/clients/client-8.png" alt=""> --}}
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Clients Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="row no-gutters">
            <div class="container">

          {{-- <div class="content col-xl-5 d-flex align-items-stretch"> --}}
            <div class="content">
              <h3 style="text-align: center;color:#e03a3c">About the Department</h3>
              <p style="text-align: justify;">
                The Department of Computer Science and Engineering was established in the year 2005 and currently the department offers an Under Graduate program B.Tech in Computer Science and Engineering with an annual intake of 240 students and 1 Post-Graduate program M.Tech in Computer Science and Engineering with an annual intake of 30 students.

                The Department is Headed by Dr. A. Sri Lakshmi is having a total experience of 19 years in Teaching and Research. Accomplished career demonstrating consistent success as an administrator and educator at the graduate and post-graduate education levels. He is an effective communicator with excellent planning, organizational, and negotiation strengths as well as the ability to lead, reach consensus, establish goals and attain results.

                There are 7 Professors, 12 Associate Professors, and 43 Assistant Professors and 10 doctorates in the department. The department has a Programmer and 5 System Administrators to assist and maintain the computer laboratories. All the faculty members are encouraged to participate in Faculty Development Programmes, Conferences, Workshops, Publication of Research Papers and active involvement in R & D activity.

                              </p>
              {{-- <a href="#" class="about-btn"><span>About us</span> <i class="bx bx-chevron-right"></i></a> --}}
            </div>

          {{-- </div> --}}
            </div>
            <div class="container">
                <div class="content">

                    <h3 style="text-align: center;color:#e03a3c">

                        Vision and Mission
                    </h3>
                    <h4 style="color:#e03a3c">vision</h4>
                    <p>
                        To produce globally competent and socially responsible computer science engineers contributing to the advancement of engineering and technology which involves creativity and innovation by providing excellent learning environment with world class facilities.


                    </p>
                    <h4 style="color:#e03a3c">Mission of the Department                    </h4>
                    <p style="text-align: justify;">
                    1.To be a centre of excellence in instruction, innovation in research and scholarship, and service to the stake holders, the profession, and the public. <br>
2.To prepare graduates to enter a rapidly changing field as a competent computer science engineer. <br>
3.To prepare graduate capable in all phases of software development, possess a firm understanding of hardware technologies, have the strong mathematical background necessary for scientific computing, and be sufficiently well versed in general theory to allow growth within the discipline as it advances. <br>
4.To prepare graduates to assume leadership roles by possessing good communication skills, the ability to work effectively as team members, and an appreciation for their social and ethical responsibility in a global setting <br>
                    </p>
                    <h4 style="color:#e03a3c ">
                        PEOs, POs, COs, and Mapping


                    </h4>
                    <h4 style="color:#e03a3c">PROGRAM EDUCATIONAL OBJECTIVES:</h4>

                    <p>
                    <ol>
        <li align="justify">To provide graduates with a good foundation in mathematics, sciences and engineering fundamentals required to solve engineering problems that will facilitate them to find employment in industry and / or to pursue postgraduate studies with an appreciation for lifelong learning.</li>
        <li align="justify">To provide graduates with analytical and problem solving skills to design algorithms, other hardware / software systems, and inculcate professional ethics, inter-personal skills to work in a multi-cultural team.</li>
        <li align="justify">To facilitate graduates get familiarized with state of the art software / hardware tools, imbibing creativity and Innovation that would enable them to develop cutting-edge technologies of multi-disciplinary nature for societal development.</li></ol></p>

        <h4 style="color:#e03a3c">  PROGRAMME OUTCOMES:</h4>
                    <p>
                    The Program outcomes of B.Tech (CSE) department are being modified with reference to Graduate Attributes given by NBA in June 2015 are as below <br>
                    <ol>
        <li align="justify"><strong>Engineering knowledge: </strong>Apply the knowledge of mathematics, science, engineering fundamentals, and an engineering specialization to the solution of complex engineering problems.</li>
        <li align="justify"><strong>Problem  analysis:  </strong>Identify,  formulate,  review  research  literature,  and  analyze  complex engineering  problems  reaching  substantiated  conclusions  using  first  principles  of  mathematics, natural sciences, and engineering sciences.</li>
        <li align="justify"><strong>Design/development  of  solutions :  </strong>Design  solutions  for  complex  engineering  problems  and design  system  components  or  processes  that  meet  the  specified  needs  with  appropriate consideration  for  the  public  health  and  safety,  and  the  cultural,  societal,  and  environmental considerations.</li>
        <li align="justify"><strong>Conduct investigations of complex problems:  </strong>Use research-based knowledge and research methods including design of experiments, analysis and interpretation of data, and synthesis of the information to provide valid conclusions.</li>
        <li align="justify"><strong>Modern  tool  usage:  </strong>Create,  select,  and  apply  appropriate  techniques,  resources,  and  modern engineering and IT tools including prediction and modelling to complex engineering activities with an understanding of the limitations.</li>
        <li align="justify"><strong>The  engineer  and  society:  </strong>Apply  reasoning  informed  by  the  contextual  knowledge  to  assess societal, health, safety, legal and cultural issues and the consequent responsibilities relevant to the professional engineering practice.</li>
        <li align="justify"><strong>Environment and sustainability: </strong>Understand the impact of the professional engineering solutions in  societal  and  environmental  contexts,  and  demonstrate  the  knowledge  of,  and  need  for sustainable development.</li>
        <li align="justify"><strong>Ethics:</strong> Apply ethical principles and commit to professional ethics and responsibilities and norms of the engineering practice.</li>
        <li align="justify"><strong>Individual and team work:</strong>  Function effectively as an individual, and as a member or leader in diverse teams, and in multidisciplinary settings.</li>
        <li align="justify"><strong>Communication: </strong>Communicate effectively on complex engineering activities with the engineering community and with society at large, such as, being able to comprehend and write effective reports and design documentation, make effective presentations, and give and receive clear instructions.</li>
        <li align="justify"><strong>Project  management  and  finance:</strong>  Demonstrate  knowledge  and  understanding  of  the engineering  and  management  principles  and  apply  these  to  one’s  own  work,  as  a  member  and leader in a team, to manage projects and in multidisciplinary environments.</li>
        <li align="justify"><strong>Life-long learning :</strong>  Recognize  the  need  for, and  have  the  preparation  and  ability  to  engage  in independent and life-long learning in the broadest context of technological change.</li>
        </ol>
        </p>
        <h4 style="color:#e03a3c">PROGRAM SPECIFIC OUTCOMES:</h4>
          <p>
                    <ol>
        <li align="justify">To identify and define the computing requirements for its solution under given constraints.</li>
        <li align="justify">To follow the best practices namely SEI-CMM levels and six sigma which varies from time to time for software development project using open ended programming environment to produce software deliverables as per customer needs</li>
        </ol>
        </p>

        {{-- <p><a href="#" class="btn"><em>Mapping of COs to POs, POs to PEOs and PEOs to Vision and Mission of the Department </em></a></p> --}}

                </div>

            </div>
            </div>
          {{-- <div class="col-xl-7 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-receipt"></i>
                  <h4>Corporis voluptates sit</h4>
                  <p>Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-cube-alt"></i>
                  <h4>Ullamco laboris nisi</h4>
                  <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
                  <i class="bx bx-images"></i>
                  <h4>Labore consequatur</h4>
                  <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
                  <i class="bx bx-shield"></i>
                  <h4>Beatae veritatis</h4>
                  <p>Expedita veritatis consequuntur nihil tempore laudantium vitae denat pacta</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div> --}}
        </div>

      </div>
    </section><!-- End About Section -->

    {{-- <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">232</span>
              <p>Happy Clients</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">521</span>
              <p>Projects</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-live-support"></i>
              <span data-toggle="counter-up">1,463</span>
              <p>Hours Of Support</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">15</span>
              <p>Hard Workers</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section --> --}}

    <!-- ======= Tabs Section ======= -->
    {{-- <section id="tabs" class="tabs">
      <div class="container" data-aos="fade-up">

        <ul class="nav nav-tabs row d-flex">
          <li class="nav-item col-3">
            <a class="nav-link active show" data-toggle="tab" href="#tab-1">
              <i class="ri-gps-line"></i>
              <h4 class="d-none d-lg-block">Modi sit est dela pireda nest</h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-2">
              <i class="ri-body-scan-line"></i>
              <h4 class="d-none d-lg-block">Unde praesenti mara setra le</h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-3">
              <i class="ri-sun-line"></i>
              <h4 class="d-none d-lg-block">Pariatur explica nitro dela</h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-4">
              <i class="ri-store-line"></i>
              <h4 class="d-none d-lg-block">Nostrum qui dile node</h4>
            </a>
          </li>
        </ul>

        <div class="tab-content">
          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
                <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200">
                <img src="assets/img/tabs-1.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Neque exercitationem debitis soluta quos debitis quo mollitia officia est</h3>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Provident mollitia neque rerum asperiores dolores quos qui a. Ipsum neque dolor voluptate nisi sed.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/tabs-2.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Voluptatibus commodi ut accusamus ea repudiandae ut autem dolor ut assumenda</h3>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Provident mollitia neque rerum asperiores dolores quos qui a. Ipsum neque dolor voluptate nisi sed.</li>
                </ul>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/tabs-3.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Omnis fugiat ea explicabo sunt dolorum asperiores sequi inventore rerum</h3>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
                <p class="font-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/tabs-4.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Tabs Section --> --}}

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg ">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Syllabus</h2>
          {{-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p> --}}
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
                <i class="fa  fa-book"></i>
                <h4 style="padding-top:10px;"><a href="#">B.Tech CSE AR20 Syllabus I/II Year</a></h4>
              {{-- <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top:10px;"><a href="#">B.Tech CSE(AIML) AR20 Syllabus I/II Year</a></h4>
              {{-- <p>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px"><a href="#">B.Tech CSE(DS) AR20 Syllabus I/II Year</a></h4>
              {{-- <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">B.Tech CSE(CS) AR20 Syllabus I/II Year</a></h4>
              {{-- <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="500">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">B.Tech CSE(IOT) AR20 Syllabus I/II Year</a></h4>
              {{-- <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="600">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">B.Tech CSE AR18 Syllabus I/II/III/IV Year</a></h4>
              {{-- <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="600">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">B.Tech CSE AR16 Syllabus I/II/III Year</a></h4>
              {{-- <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="600">
                <i class="fa  fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">B.Tech CSE AR16 Syllabus IV Year</a></h4>
              {{-- <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p> --}}
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="600">
              <i class="fa fa-book"></i>
              <h4 style="padding-top: 10px;"><a href="#">M.Tech CSE Syllabus AR18</a></h4>
              {{-- <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p> --}}
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Portfolio</h2>
          {{-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p> --}}
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">FDP</li>

              <li data-filter=".filter-card">Hackathons</li>
              <li data-filter=".filter-web">Workshops</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 1</h4>
                <p>App</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-1.jpg" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 3</h4>
                <p>Web</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-2.jpg" data-gall="portfolioGallery" class="venobox" title="Web 3"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 2</h4>
                <p>App</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-3.jpg" data-gall="portfolioGallery" class="venobox" title="App 2"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 2</h4>
                <p>Card</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-4.jpg" data-gall="portfolioGallery" class="venobox" title="Card 2"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 2</h4>
                <p>Web</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-5.jpg" data-gall="portfolioGallery" class="venobox" title="Web 2"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 3</h4>
                <p>App</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-6.jpg" data-gall="portfolioGallery" class="venobox" title="App 3"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 1</h4>
                <p>Card</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-7.jpg" data-gall="portfolioGallery" class="venobox" title="Card 1"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 3</h4>
                <p>Card</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-8.jpg" data-gall="portfolioGallery" class="venobox" title="Card 3"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 3</h4>
                <p>Web</p>
                <div class="portfolio-links">
                  <a href="assets/img/portfolio/portfolio-9.jpg" data-gall="portfolioGallery" class="venobox" title="Web 3"><i class="bx bx-plus"></i></a>
                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Testimonials</h2>
            <p>A word from our students</p>
        </div>
      </div>

      <div class="container-fluid">

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">
          <div class="col-xl-10">
            <div class="owl-carousel testimonials-carousel">

              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBAQEBANEBAVDQ0NDQ0NDQ8IEA4NIBEXIiAdHx8aKDQgGiAxJxYTJDEtMSktLy4wIx8zOD8sNygtOCsBCgoKDg0OFRAQFysZFxkrKysvLSsrKy4rKzcrNzcrKzAwKzc3Kzg1NTcrKy03MSsrNy0tLSs3LSsrNysrKystLf/AABEIAMgAyAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAIDBQYBB//EADgQAAEEAAQEAwYFAwQDAAAAAAEAAgMRBAUhMQYSQVETImEHMnGBkfAUobHR8ULB4SNSYnIkQ5L/xAAbAQACAwEBAQAAAAAAAAAAAAABAgADBAUGB//EACcRAAICAgIBAwUAAwAAAAAAAAABAhEDEiExBBMiQQUUMlFxI2Gh/9oADAMBAAIRAxEAPwCcNJScwq0ZB6J34U9l1FIwPAinDSpQ0qz/AAh7Lv4Q9kdwfblXRSNqyODPZcOEKO6FfjgEZKJjfSIbhFm+OMzdhIRyGnvcWtdvymkHlikJHBboB4y4n/DvbFGAX8niOOlNBBAH6ryuWdziXOJLi4uJPm1U+Z4900he48xpoJIGtBQDkr+u/gAFgyTc2dHHjWNUhOOl38rICb4gob/LRSNDB6/C2rogG50G4buSElMtI2M679h3KkkJcALAABJ6dVIyVpby6Aiy3pr2QrZDY3JvQb62jwgFpEeWNzepYXu+JB/woYHjls+ja9VI3cXvyCx62qx7zZ7cxI+qslKqFSD4ZSbsGw4a9N1DiJKdzN6713v+E7CuvlHQlzneoQ75bu++3RK5cDUNkNn4km11k1AD11B1TALTQVVYQhry46n5DTqiJ2k0BtYv4IaJ1nb6IoO0u+3qrI8ohZYLDxkFri9p3a4H3HfDqFr+C83c1xwsxBFF0LrI67D9Vgo8Se5+tIhmLcHNIdqCKtxH5p5JOIh7LJH9+iSByfMWzwRvBN8oDwSLDqSWJ2mA1whThEiCAuEhdtpGD1WMEQUb2gKXxAhZph37qmckiyM2zppcsIKTFeqHkxvqsk836LNixdKF5T7XMxuSGBtWGmR53O5AH5FbqXHeq8i49xXiY2Q6eVrI/wAv8qrdsbEvdZRim76nr0pLxB0selqMk16aJROA3APxRs0nS6z9lTgeXQHrZN7LjcSBs1oPSgE7zOFuJA+TUyIRRRt6nXtspbaz3avvqh5HVoPr1TOYoWQKZJR1611vRNxrBYI6ivv8kOSnOeSPkB8lNuCEsc/L7v8AtqyoWi0xOCFkEVxOFJpQAdaaT3y38OyjpJEgTEdCQdq9NE10hOh+XTVNifqAdtj8FM9gquoG+/30T/BD0TgXE3hyzTmDiXHc6j+UlT+zWc/iHsOxiGnqHD90lVJ8lUpUz2M47RQvx3qqNkx7pPeUXnkzNqixlzDsUI/GkoBxJT4oyq3NvsZJInMpQ0pKOjgJUgwd9EmyJZQyFy8qzwH8RKTuZHH817g/A76LzHjTJi2UyNFczeYjbzCgR+isjJPgtxS5ox4P36Jqc5pG4I+OianLx7CpHyafvqoElAjtd1xIFTQ4dz9gSpdESshSVy7IJOUOAPqCERleQPc8c7TWug6pN0WLDJsz/IexXAF6RFww3lJDCRqRYLCVks6yd8biQ012ooRyJuh5+PKKspeVcTtklaUUID72ScP5XR6UkQmAd3HwUrH3qexCi6J4oH77IgNh7MGg4mUncRaf/X+AkofZxf4pxuh4DrHfzBcWfIuTPk/I9GijU4hU0UVIhrFVsU2ADDFEw4ekQGp3MAg5B5E1oCkBCHdMmiZVtgDKCq84ylszdhY91wIaRp17otsyeJQhu0wKTT4PE+NMtMEw283NtrqDqs4vU/anlxfAydupjeQ8V/QRv+QWJwGUB0THkG3EkV11/ha45PbbOhhTyLgpTEUmxE9FqxkhNWNPqVZYPIWN1qzR9daSPOkbI+I2ZbLMoMjhYNdQL2W4ynIAKodibAVll2WNYByjXc31Kv8ADxtaNtdL+KzzzOTN2LxlBclY3KiNqHXoRafBlRsAho1JIbe6t3St+7CYZKGn7pFJl2iI2YflG/1aNlTZ21paRTSddXC1aTzfeqzmd4kgHYHvd6q2KtleRpI88zfB8ryR1s7cvVVhCuM2n5rN99tNaVRS2o48+zlJapLqIhwJ7dT8b9NKXPv5rjTqmAa72dPDcbyEe9FI1p281X/YpLns0ja7HAkmxHK5o31pJUZu0Z8itnrdJwKZaRcsxUkJ70PJMnSFQOapYxwyJhkXSxQvBSsDRMJSp2yoSNhRAjKQSiPMYGzRujdq1zS0rN5VlfLGyM0eRoZdVZC1ElNBJ0ABJ6aUoMqjB101s/O091GjrfTI22BRZb/IHVTswYBAOn7K9bAAFFOwDXTt30VMrO5GgPDxAHYovwHdqCTJ2N1JAA7qrzLjXDRgjxGWBsCCjCGws8ij2WEjSPu1E+1hcf7Q3WRHqNPNXKh8BxriA+3NL2HdvLZA9FpWBmb7qNm/DL3+iU2WRvGo3+SoIOKRI8DwpADVudcdfVaOCYOALSD10Icm0aQVNTMVnfBYdbovXQ2dVg80y98DuVw7+uq9/Y0Ef2WA9pGUt5fFFA7u+CaE30zNnwqrR5iugrgCcVeYRWuPXoXBWRww8s+IaJZnV4MDq5Wep9VqOJMvfiYvCxGHwzWkf6U8bf8AVhNaEHqO4SPNHo0rxJuN/JivZYxv4p7iacIHcg7guaCkh+GGOwWY+FMKcCYSQeYeaqI7g6fVcUnBypo52RVKmj1bnTS9OpNLVksqOAqVrLTGtU7P2SORCN0SiMCMCeAl2JQMzDqTwkQAu0hsSjEe0vESw4Vnh2A6cNkcL90NsD5n9FjMt41nioFrXD5g0vYMzwEc8To5QCwj4Ue68ezrLAcUYMN4WI2DTBTgDroTsCtOKSktWjZ40mlw6Ztck4wZPpdHTQ6HZW78yBsWF45iYpMNK9juUPY8NcA6yHendazhjMXYhwjI8xFg78wSZcNcro6/j+Tt7X2N4pzCaQ+G0uDRuGkiwso7AG/Ma79dF6JnORSXsbrsVk80y2WMedpALgO1m9kcc64QubFbtkGWQwDaKSU9TVhXzcW1gr8NI0b01rX6/Iorh/hrCSQSePMBNyPDAZHNjZJWlAb9FmsLwzinOAc2OMN0LvEALhe+hV2qfyU+6HCiXjc5hOlUez2lpv5q1yzMNfL1oGuyqcJw00yayufqTyAl4b81s8nyJjOl7dKVU+Omacd/KLTBSFwHyQXEuDEsEgcCaB9dKV1BhuU3Y5eUANDQKdZ1v6ITNPccL/pP6KR45DLng8CxsHI5w+i0vC3DniMGIkI5OZ3IzqXA9VT53GTK4DYOIHTS16TwThw/L42nQgyNv/kXHVapfjZzsUV6lMblGIwZkc2SQtxDHkUQaOnRa6fEsliFG+X9PulgcLkDpZJHUS8PdZAotkBrX40rjLnPZ4jXWKY67NarC3ydeC45MVxw/lzJhGlMw5Nd7/hJVfFuJL8dI7sYgPk0f5SXUwuoJHDz08kv6e0hidyBdpNcVx9jDQi1NBXDKmF6KVhona5SByEEikY5DUPQQZF0SIdzlG6RShewt0gqjt6rMcTMdF4U0YaGhxaWhvI29+nXdW7plYxNbLF4bmNc03o4A2rMXDZu8LG5Sv8AR5Jm3hYiZ0r4GmR1BxEjmNJrehqTstp7N+HgJnTObQYwNY3V2p/xSsZOHcPFb2xgHXcXS0fC+FLYS7YucT8k6k5OjrPGorb5OZvheY6Dauyz2Y5AJxR8rhq1wAOq1uKkA33VZJiW3+SSS54LIttGDn4dxMTjyta8d7LUbl/D08nv0xu5Db2WtfID1+XojMLMxos10Sp2x2qQFl/DsUTdhe/U6o2VoYLDSSK0AAtHOxUdfYVdisW38j23VvBTTZyZ2g6WBvSq8wZYOvQiwfRKbMW2ASN6+aq83x1NNaHp01Ri7YJKkYXiDDNYdALJvazVq/4XxnLhZwT7tSNbvQr+Fnc9mc/lBq7Li7YV90rHgicc0weQW+GCfgDa117GjBF/5EbDhjDyVJMS5t2RztNvPelWZtiK5w0OJLiZZCOXS9gtpl5YGB/M3lq2k1tSzGbTNllJYAGA9NA9/dZY49mb5TcUeSPifNjAHAh0k+xB0Bcktfj8t/8ALgmaBTZQ5wGhu0l0IxaXBxci9x6KSoJHJznqJ2q5CjZluhjnJpcnEJpVlUgpnA5TRyIdyYZKSWM0GOkUEkqClxSgOJvqjq2SMQuWVWOBxw27Kku1BPMY6N0Dp81HGkdHwMqjPV/JpsTmMYBL61BDQTVuVvl+bwtia0uqgBW68uxuYRyOEchbRqwapUWJ4jdG90THuLB5Wud5iAjCMn0dLLkxrhnq+a8c5fAalJLugbbz9BsgG8a5biA4NDm6HVzXM1+ei8rGOii89Mkc6zqPEJOupJU7OIInEGSNulaGyN+yt9NlHrpPs9CwWPdJGXgkjmdyE2OaME0UThc1vt/lUOE4iw/hmiKrT+nVZ3H8QN5yWGj36EKl4pX0afuIJK2ehRYjkBAc8iyRzvL6N90JPmZF7+nxWbyzNzLp17b6KwLwQSfW/RLVOmO8ikrQZFJznXQb9tUFmeIPKRudfomxYgaAEG7/AEVbiscC8N12AN+W21/Kvxx5MuafBTYyTmHUnRoHu6IzhN4D3tJFOjew9NCFTY+XzOA0FmgNKCmymXlcKOprXsFtSOddOzbYfDThrYzLIYwAOUnorFwDWpmV4kPYDoaAHf76oLNscGggnQNL310aq1GpUjZtcLZFPig0E9deUdSUlS+J4vnvQ1TTpQSXosH07aCcnRyMudbOj0DnXeZV8c5RcZXkFwJqdc4ppepOQqN8aj5REiGWVDvkJUsrFDSkYj2DyArkbPiiCxPjYntIA+GND59hSYC5vvMIlaCeWyOn0tWMTFLygiiAR1B10SKRFLV2jx7iB3+oyRhJY9jXsP8Ab8lX4bDOldpXqTor/iLLDBijGQfAL3SQXq3lOpCuMqyeA8shaCNPKfLqtSmkkdHFj9aV2U0/D0fgBzJHOk3LSGtafTuqVuBfpp121JXqrcJhG0fAjB1vmc4iq7Js+KwsY0EDD/xaGIKZ0ZfT4dt0ebty+cM0jfX+6i0IGTBSi7Y76L0qPFeKaiaXX/7HAtAF9ArjA5JGBzSAE1dGjqhPMomd+JGXTPOeEC6OV3O014Z0II1V3JmFkj6URqjs0wzedzmAdRpoqJ8Aa8PNnymwP91qnbZ2Nq8cdbDI8VyEHqOVtE35iP4VbinDmLrdoNdx99V3G4sMbZGtk/BU2MxxLaHWjvei0Y4/Jmyz+CLFYiya63siMBIAQT8viqrmRGFko2emyvTMt2zdZTmAjjOvQ/f6oPN5rAicR4slSSjs3oFFwzAZCZHaRR+bXTnk/YKGVhkkfKdOY6E37qv8TE8ubrhFuaemL+hUNCgNdvd2CS7CwN2SXrYRaRxZS5NdGFZQIWOP73UpNfdL5zI29hvMP0THuCCdiFw4hRCtEkzggZHJ0shP5qClYiErHImJDxRo6Jn9kkmMSMCe0pwCY4qr+CXyV2eZYzExljtDryPoEtd3/RZLJXESS4OYeZuhGuvqPyW6BWO41f8Ah8Rh8SwDmIdHJV27QVatxu/aavGy6y/0U+dZPO2SmySFpsgFzjyjsisi4Uc97TK4VeoJLtFPFnAmp2l0b9NUWMzDK6a6fBWtySo6ajBvY1uEwDImhjAABp0Qeb47kaW81brNScSGrJPWiDsqXOM3Jo3ZLKIvQj91WsLbtjz8hKNIJlzmndzYF7df4QuNxwAFCys67EG/XXX0THzkrT6aMLzsKzHFl5F9BXfVAuK4SkrEqM8pWJFYDDOleGDTuejR3QwFrSZVhOVm2pou9R2Wjx8Es0tYiuSirZbRzFsYij0YAW9Dz+p/NRsb1Op/snyAigdN7TQegXqcOCGJaxRz8mWU3bY4ffVJPae2/dJaSk2LXrkpTS2l1gXzc33QzlK62NE8i6GBRMLYM6JcbEinBRFSwDo2Kdqia9PCWSATcyienBda1VgZE0FV/EOUDFQubrzAHkIryn7pWhUTpaTx4doZOjxzGYWbCSFkgLSCe9OF9FyXMi4a3a9VzLL4sQKkY12oNEb7/uVTy8B4V4Ja6RhO3KecD5Falli+y+OZpUedvxbiKUJkJ3K3eJ9nRq459auns0vssvnfD8+EdUjbafdkaC5jv2VsZRfQd7+SpK4nmM9iu+EU9h1Yxda0lEQ4UlWmCwPSte++ikE5yUY8tjenSt9A+WZeSQXaDQrSYYa6fYUQjDRQU2Hdp9V6nwvFWBU+/k52bJu+OjrwbSaRsFG8k+nwXQt18lBIXLqhSU2AbwxrgZSk5kxxXzijdY+1wuUJtOaChq0GzkkiGdJr9URIxCuYniCwiI2iWlBR6KTxVJECg5PDggvFXRJ97JWhWTyOQkhT3SJlhGKJYxpKLifSganEoSG7DBKszxxjAI2RA6uPO/8A6jb+6uedYPiTGiXESUQQ0hjfgB/K6P03Ftkcn0hWVwjYTXUgFt9Uz8PrtSgndpY3BNHZH4HENkADtHgX/wBhe6t8vx6lcDf4+VNVI7DB6KwjAaKFepUbCPl9Vwm/vouv9P8ACWCO8uZP/hl8ryN3rH8RxdafA40fmo6vZSRuaNDv2HwXTT5tmI70tLmUfiN6uaPQkNXQ8dC0/Agptl+xaHEpKJ7iTQ2SQ2Ckb103RJslpJLwNGkIYE/lCSSDFGPAQ7gEklESyMqM2kkmHRy11z0kkCUDSzFcZiEkkQBMcil8RJJChkC4ybkY95/pY52vev4XmrnF1nqSXE+qSS6/09LR/wBIxpHlI9R9aU2FjDfMfed5WejV1JdCMVaYL4LBhv4fXROfKG1aSS3bNRsp7YI/Ek+6S0d9r+CYHO7k/FJJZ9m2PSoXhk767eqRhHb6aJJJ9UAc1rh7r3D0PmCSSSZIRyP/2Q==" class="testimonial-img" alt="">
                  <h3>Saiesh Parimi</h3>
                  <h4>Placed at amazon</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sit totam, iste cumque mollitia a optio dolor laborum voluptatibus omnis nisi incidunt quia quam alias eaque temporibus minima in similique ex!
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>

              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="https://geethanjaliapp.com/admins/images/aditya.jpg" class="testimonial-img" alt="">
                  <h3>Gadepalli Aditya</h3>
                  <h4>Placed at Keka</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati blanditiis voluptatibus eligendi ut a quas magni atque. Inventore sint id rem minima maxime minus sapiente earum, deleniti tenetur nostrum eius.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>

              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="https://he-s3.s3.amazonaws.com/media/avatars/SantoshPisini/resized/180/62267cd17.jpg" class="testimonial-img" alt="">
                  <h3>Santosh Pisini</h3>
                  <h4>Placed at EPAM</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestiae magnam illo pariatur ut quas ratione iste vero unde perspiciatis, ducimus sequi labore dicta, officia modi expedita officiis? Dolor, aut eius.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>

              {{-- <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                  <h3>Matt Brandon</h3>
                  <h4>Freelancer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>

              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                  <h3>John Larson</h3>
                  <h4>Entrepreneur</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat esse veniam culpa fore nisi cillum quid.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div> --}}

            </div>
          </div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Pricing Section ======= -->
    {{-- <section id="pricing" class="pricing section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Pricing</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="box" data-aos="fade-up" data-aos-delay="100">
              <h3>Free</h3>
              <h4><sup>$</sup>0<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li class="na">Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-md-0">
            <div class="box featured" data-aos="fade-up" data-aos-delay="200">
              <h3>Business</h3>
              <h4><sup>$</sup>19<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-lg-0">
            <div class="box" data-aos="fade-up" data-aos-delay="300">
              <h3>Developer</h3>
              <h4><sup>$</sup>29<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section --> --}}

    <!-- ======= Frequently Asked Questions Section ======= -->
    {{-- <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
        </div>

        <ul class="faq-list" data-aos="fade-up">

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq1">Non consectetur a erat nam at lectus urna duis? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq1" class="collapse" data-parent=".faq-list">
              <p>
                Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq2" class="collapsed">Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq2" class="collapse" data-parent=".faq-list">
              <p>
                Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq3" class="collapsed">Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq3" class="collapse" data-parent=".faq-list">
              <p>
                Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq4" class="collapsed">Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq4" class="collapse" data-parent=".faq-list">
              <p>
                Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq5" class="collapsed">Tempus quam pellentesque nec nam aliquam sem et tortor consequat? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq5" class="collapse" data-parent=".faq-list">
              <p>
                Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq6" class="collapsed">Tortor vitae purus faucibus ornare. Varius vel pharetra vel turpis nunc eget lorem dolor? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq6" class="collapse" data-parent=".faq-list">
              <p>
                Laoreet sit amet cursus sit amet dictum sit amet justo. Mauris vitae ultricies leo integer malesuada nunc vel. Tincidunt eget nullam non nisi est sit amet. Turpis nunc eget lorem dolor sed. Ut venenatis tellus in metus vulputate eu scelerisque. Pellentesque diam volutpat commodo sed egestas egestas fringilla phasellus faucibus. Nibh tellus molestie nunc non blandit massa enim nec.
              </p>
            </div>
          </li>

        </ul>

      </div>
    </section><!-- End Frequently Asked Questions Section --> --}}

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Our Faculty</h2>
          {{-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.</p> --}}
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="https://p.kindpng.com/picc/s/111-1114911_person-icon-png-download-icono-usuario-png-transparent.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Name</h4>
                <span>Designation</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="https://p.kindpng.com/picc/s/111-1114911_person-icon-png-download-icono-usuario-png-transparent.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Name</h4>
                <span>Designation</span>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="https://p.kindpng.com/picc/s/111-1114911_person-icon-png-download-icono-usuario-png-transparent.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Name</h4>
                <span>Designation</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="https://p.kindpng.com/picc/s/111-1114911_person-icon-png-download-icono-usuario-png-transparent.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Name</h4>
                <span>Designation</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6">

            <div class="row">
              <div class="col-md-12">
                <div class="info-box">
                  <i class="bx bx-map"></i>
                  <h3>Our Address</h3>
                  <p>Department of Computer Science & Engineering
                    <p>Geethanjali college of Engineering and Technology</p>
                </p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email Us</h3>
                  <p>info@example.com<br>contact@example.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Call Us</h3>
                  <p>+91-12334567890<br>+91 1234567890</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          {{-- <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Presento<span>.</span></h3>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div> --}}

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="http://www.geethanjaliinstitutions.com/engineering/">Geethanjali college of Engineering and Technology</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="http://www.geethanjaliinstitutions.com/engineering/infrastucture.htm">Infrastucture</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="http://www.geethanjaliinstitutions.com/engineering/library.html">Library</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="http://www.geethanjaliinstitutions.com/engineering/transport.html">Transport</a></li>
            </ul>
          </div>

          {{-- <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div> --}}

          {{-- <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div> --}}

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          {{-- &copy; Copyright <strong><span>Presento</span></strong>. All Rights Reserved --}}
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/presento-bootstrap-corporate-template/ -->
          Designed by <a href="https://geethanjaliapp.com/">Geethanjali App</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="{{asset('assets/vendor/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('assets/venphdor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('assets/vendor/jquery.easing/jquery.easing.min.js')}}"></script>
  <script src="{{asset('assets/vendor/php-email-form/validate.js')}}"></script>
  <script src="{{asset('assets/vendor/owl.carousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('assets/vendor/waypoints/jquery.waypoints.min.js')}}"></script>
  <script src="{{asset('assets/vendor/counterup/counterup.min.js')}}"></script>
  <script src="{{asset('assets/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('assets/vendor/venobox/venobox.min.js')}}"></script>
  <script src="{{asset('assets/vendor/aos/aos.js')}}"></script>

  <!-- Template Main JS File -->
  <script src="{{asset('assets/js/main.js')}}"></script>

</body>

</html>
